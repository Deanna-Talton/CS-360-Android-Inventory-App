package com.example.deannataltoninventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * Manages the application's persistent SQLite database.
 *
 * The database contains separate tables for user accounts and inventory
 * records. Activities communicate with this helper instead of containing
 * SQL statements, which keeps database responsibilities centralized.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 1;

    // User account table and column names.
    public static final String TABLE_USERS = "users";
    public static final String USER_COLUMN_ID = "user_id";
    public static final String USER_COLUMN_USERNAME = "username";
    public static final String USER_COLUMN_PASSWORD_HASH = "password_hash";
    public static final String USER_COLUMN_PASSWORD_SALT = "password_salt";

    // Inventory table and column names.
    public static final String TABLE_INVENTORY = "inventory";
    public static final String INVENTORY_COLUMN_ID = "item_id";
    public static final String INVENTORY_COLUMN_NAME = "item_name";
    public static final String INVENTORY_COLUMN_DESCRIPTION = "description";
    public static final String INVENTORY_COLUMN_CATEGORY = "category";
    public static final String INVENTORY_COLUMN_QUANTITY = "quantity";

    private static final int SALT_LENGTH_BYTES = 16;

    /**
     * Initializes the database helper using the application context.
     */
    public DatabaseHelper(Context context) {
        super(
                context.getApplicationContext(),
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    /**
     * Creates the required database tables the first time the app accesses
     * the database.
     */
    @Override
    public void onCreate(SQLiteDatabase database) {
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " ("
                        + USER_COLUMN_ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + USER_COLUMN_USERNAME
                        + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                        + USER_COLUMN_PASSWORD_HASH
                        + " TEXT NOT NULL, "
                        + USER_COLUMN_PASSWORD_SALT
                        + " TEXT NOT NULL)";

        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " ("
                        + INVENTORY_COLUMN_ID
                        + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + INVENTORY_COLUMN_NAME
                        + " TEXT NOT NULL, "
                        + INVENTORY_COLUMN_DESCRIPTION
                        + " TEXT NOT NULL DEFAULT '', "
                        + INVENTORY_COLUMN_CATEGORY
                        + " TEXT NOT NULL DEFAULT 'General', "
                        + INVENTORY_COLUMN_QUANTITY
                        + " INTEGER NOT NULL DEFAULT 0 "
                        + "CHECK("
                        + INVENTORY_COLUMN_QUANTITY
                        + " >= 0))";

        database.execSQL(createUsersTable);
        database.execSQL(createInventoryTable);

        /*
         * These initial records preserve the four inventory examples already
         * represented by the Project Two interface. They are inserted only
         * when the database is first created.
         */
        insertInitialInventoryItem(
                database,
                "Safety Gloves",
                "Protective warehouse gloves",
                "Safety",
                24
        );

        insertInitialInventoryItem(
                database,
                "Packing Tape",
                "General-purpose packing tape",
                "Shipping",
                8
        );

        insertInitialInventoryItem(
                database,
                "Printer Paper",
                "Standard printer paper",
                "Office",
                0
        );

        insertInitialInventoryItem(
                database,
                "Shipping Boxes",
                "Standard warehouse shipping boxes",
                "Shipping",
                16
        );
    }

    /**
     * Recreates the tables if a future database version requires a structural
     * change. DATABASE_VERSION should be increased whenever the schema changes.
     */
    @Override
    public void onUpgrade(
            SQLiteDatabase database,
            int oldVersion,
            int newVersion
    ) {
        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_INVENTORY
        );

        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_USERS
        );

        onCreate(database);
    }

    /**
     * Saves a new account if its username is not already registered.
     *
     * @return true when the account is created; false for duplicate or
     * invalid account information
     */
    public boolean createUser(String username, String password) {
        String normalizedUsername =
                username == null ? "" : username.trim();

        if (normalizedUsername.isEmpty()
                || password == null
                || password.isEmpty()
                || usernameExists(normalizedUsername)) {
            return false;
        }

        byte[] salt = createPasswordSalt();
        String encodedSalt =
                Base64.encodeToString(salt, Base64.NO_WRAP);

        String passwordHash =
                hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put(USER_COLUMN_USERNAME, normalizedUsername);
        values.put(USER_COLUMN_PASSWORD_HASH, passwordHash);
        values.put(USER_COLUMN_PASSWORD_SALT, encodedSalt);

        SQLiteDatabase database =
                getWritableDatabase();

        long insertedRowId =
                database.insert(
                        TABLE_USERS,
                        null,
                        values
                );

        return insertedRowId != -1;
    }

    /**
     * Checks the submitted credentials against the persistent users table.
     */
    public boolean validateUser(String username, String password) {
        String normalizedUsername =
                username == null ? "" : username.trim();

        if (normalizedUsername.isEmpty()
                || password == null
                || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase database =
                getReadableDatabase();

        String[] columns = {
                USER_COLUMN_PASSWORD_HASH,
                USER_COLUMN_PASSWORD_SALT
        };

        String selection =
                USER_COLUMN_USERNAME + " = ?";

        String[] selectionArguments = {
                normalizedUsername
        };

        try (Cursor cursor = database.query(
                TABLE_USERS,
                columns,
                selection,
                selectionArguments,
                null,
                null,
                null
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }

            int hashColumnIndex =
                    cursor.getColumnIndexOrThrow(
                            USER_COLUMN_PASSWORD_HASH
                    );

            int saltColumnIndex =
                    cursor.getColumnIndexOrThrow(
                            USER_COLUMN_PASSWORD_SALT
                    );

            String storedHash =
                    cursor.getString(hashColumnIndex);

            String storedSalt =
                    cursor.getString(saltColumnIndex);

            byte[] decodedSalt =
                    Base64.decode(storedSalt, Base64.NO_WRAP);

            String submittedPasswordHash =
                    hashPassword(password, decodedSalt);

            /*
             * A constant-time comparison avoids returning early when bytes
             * differ, which is safer for credential validation.
             */
            return MessageDigest.isEqual(
                    storedHash.getBytes(StandardCharsets.UTF_8),
                    submittedPasswordHash.getBytes(
                            StandardCharsets.UTF_8
                    )
            );
        }
    }

    /**
     * Determines whether a username is already registered.
     */
    public boolean usernameExists(String username) {
        String normalizedUsername =
                username == null ? "" : username.trim();

        if (normalizedUsername.isEmpty()) {
            return false;
        }

        SQLiteDatabase database =
                getReadableDatabase();

        String selection =
                USER_COLUMN_USERNAME + " = ?";

        String[] selectionArguments = {
                normalizedUsername
        };

        try (Cursor cursor = database.query(
                TABLE_USERS,
                new String[]{USER_COLUMN_ID},
                selection,
                selectionArguments,
                null,
                null,
                null
        )) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Adds a new inventory record and returns its generated database ID.
     *
     * @return the new row ID, or -1 if the insert fails
     */
    public long addInventoryItem(
            String itemName,
            String description,
            String category,
            int quantity
    ) {
        if (itemName == null || itemName.trim().isEmpty()) {
            return -1;
        }

        ContentValues values =
                createInventoryValues(
                        itemName,
                        description,
                        category,
                        quantity
                );

        SQLiteDatabase database =
                getWritableDatabase();

        return database.insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    /**
     * Retrieves all inventory records in alphabetical order for display.
     *
     * The activity that receives this Cursor must close it after reading it.
     */
    public Cursor getAllInventoryItems() {
        SQLiteDatabase database =
                getReadableDatabase();

        return database.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                INVENTORY_COLUMN_NAME + " COLLATE NOCASE ASC"
        );
    }

    /**
     * Retrieves one inventory record by its unique database ID.
     *
     * The activity that receives this Cursor must close it after reading it.
     */
    public Cursor getInventoryItem(long itemId) {
        SQLiteDatabase database =
                getReadableDatabase();

        return database.query(
                TABLE_INVENTORY,
                null,
                INVENTORY_COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)},
                null,
                null,
                null
        );
    }

    /**
     * Updates all editable values for an existing inventory record.
     */
    public boolean updateInventoryItem(
            long itemId,
            String itemName,
            String description,
            String category,
            int quantity
    ) {
        if (itemId <= 0
                || itemName == null
                || itemName.trim().isEmpty()) {
            return false;
        }

        ContentValues values =
                createInventoryValues(
                        itemName,
                        description,
                        category,
                        quantity
                );

        SQLiteDatabase database =
                getWritableDatabase();

        int affectedRows =
                database.update(
                        TABLE_INVENTORY,
                        values,
                        INVENTORY_COLUMN_ID + " = ?",
                        new String[]{String.valueOf(itemId)}
                );

        return affectedRows > 0;
    }

    /**
     * Updates only an item's quantity.
     *
     * Quantities are clamped to zero so inventory can never become negative.
     */
    public boolean updateInventoryQuantity(
            long itemId,
            int quantity
    ) {
        if (itemId <= 0) {
            return false;
        }

        ContentValues values =
                new ContentValues();

        values.put(
                INVENTORY_COLUMN_QUANTITY,
                Math.max(quantity, 0)
        );

        SQLiteDatabase database =
                getWritableDatabase();

        int affectedRows =
                database.update(
                        TABLE_INVENTORY,
                        values,
                        INVENTORY_COLUMN_ID + " = ?",
                        new String[]{String.valueOf(itemId)}
                );

        return affectedRows > 0;
    }

    /**
     * Permanently removes an inventory record by its database ID.
     */
    public boolean deleteInventoryItem(long itemId) {
        if (itemId <= 0) {
            return false;
        }

        SQLiteDatabase database =
                getWritableDatabase();

        int affectedRows =
                database.delete(
                        TABLE_INVENTORY,
                        INVENTORY_COLUMN_ID + " = ?",
                        new String[]{String.valueOf(itemId)}
                );

        return affectedRows > 0;
    }

    /**
     * Creates consistently normalized values for inventory inserts and
     * updates.
     */
    private ContentValues createInventoryValues(
            String itemName,
            String description,
            String category,
            int quantity
    ) {
        String safeDescription =
                description == null ? "" : description.trim();

        String safeCategory =
                category == null || category.trim().isEmpty()
                        ? "General"
                        : category.trim();

        ContentValues values =
                new ContentValues();

        values.put(
                INVENTORY_COLUMN_NAME,
                itemName.trim()
        );

        values.put(
                INVENTORY_COLUMN_DESCRIPTION,
                safeDescription
        );

        values.put(
                INVENTORY_COLUMN_CATEGORY,
                safeCategory
        );

        values.put(
                INVENTORY_COLUMN_QUANTITY,
                Math.max(quantity, 0)
        );

        return values;
    }

    /**
     * Inserts a starter inventory record while the database is being created.
     */
    private void insertInitialInventoryItem(
            SQLiteDatabase database,
            String itemName,
            String description,
            String category,
            int quantity
    ) {
        ContentValues values =
                createInventoryValues(
                        itemName,
                        description,
                        category,
                        quantity
                );

        database.insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    /**
     * Generates a unique random salt for each stored password.
     */
    private byte[] createPasswordSalt() {
        byte[] salt =
                new byte[SALT_LENGTH_BYTES];

        SecureRandom secureRandom =
                new SecureRandom();

        secureRandom.nextBytes(salt);

        return salt;
    }

    /**
     * Produces a salted SHA-256 password hash so readable passwords are never
     * stored in the SQLite database.
     */
    private String hashPassword(
            String password,
            byte[] salt
    ) {
        try {
            MessageDigest messageDigest =
                    MessageDigest.getInstance("SHA-256");

            messageDigest.update(salt);

            byte[] hashedPassword =
                    messageDigest.digest(
                            password.getBytes(StandardCharsets.UTF_8)
                    );

            return Base64.encodeToString(
                    hashedPassword,
                    Base64.NO_WRAP
            );
        } catch (Exception exception) {
            /*
             * SHA-256 is guaranteed by the Java platform. Converting an
             * unexpected provider failure into an application exception
             * prevents insecure password storage.
             */
            throw new IllegalStateException(
                    "Unable to securely process the password.",
                    exception
            );
        }
    }
}