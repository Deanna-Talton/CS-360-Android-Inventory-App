package com.example.deannataltoninventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Controls database-backed login and account creation.
 *
 * New credentials are saved in SQLite, while returning users must enter a
 * username and password that match an existing database record.
 */
public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin =
                findViewById(R.id.buttonLogin);

        Button buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        /*
         * A single database helper manages both user credentials and
         * inventory records throughout the application.
         */
        databaseHelper =
                new DatabaseHelper(getApplicationContext());

        buttonLogin.setOnClickListener(
                view -> attemptLogin()
        );

        buttonCreateAccount.setOnClickListener(
                view -> attemptAccountCreation()
        );
    }

    /**
     * Validates the form and checks the entered credentials against SQLite.
     */
    private void attemptLogin() {
        if (!validateCredentialFields()) {
            return;
        }

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        boolean validCredentials =
                databaseHelper.validateUser(
                        username,
                        password
                );

        if (!validCredentials) {
            Toast.makeText(
                    this,
                    R.string.invalid_credentials,
                    Toast.LENGTH_SHORT
            ).show();

            /*
             * Clearing only the password protects the entered credential while
             * allowing the user to correct a username typo if necessary.
             */
            editPassword.setText("");
            editPassword.requestFocus();
            return;
        }

        Toast.makeText(
                this,
                R.string.login_successful,
                Toast.LENGTH_SHORT
        ).show();

        openInventoryScreen();
    }

    /**
     * Validates and stores a first-time user's credentials in SQLite.
     */
    private void attemptAccountCreation() {
        if (!validateCredentialFields()) {
            return;
        }

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        if (databaseHelper.usernameExists(username)) {
            editUsername.setError(
                    getString(R.string.username_already_exists)
            );

            editUsername.requestFocus();
            return;
        }

        boolean accountCreated =
                databaseHelper.createUser(
                        username,
                        password
                );

        if (!accountCreated) {
            Toast.makeText(
                    this,
                    R.string.account_creation_failed,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Toast.makeText(
                this,
                R.string.account_created,
                Toast.LENGTH_SHORT
        ).show();

        /*
         * Successful account creation also signs in the new user, avoiding
         * an unnecessary second credential entry.
         */
        openInventoryScreen();
    }

    /**
     * Confirms that both credential fields contain user input.
     *
     * Errors are attached directly to the relevant fields so the user can
     * quickly identify and correct missing information.
     */
    private boolean validateCredentialFields() {
        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        editUsername.setError(null);
        editPassword.setError(null);

        if (username.isEmpty()) {
            editUsername.setError(
                    getString(R.string.username_required)
            );

            editUsername.requestFocus();
            return false;
        }

        if (password.isEmpty()) {
            editPassword.setError(
                    getString(R.string.password_required)
            );

            editPassword.requestFocus();
            return false;
        }

        return true;
    }

    /**
     * Opens the authenticated inventory-management screen.
     */
    private void openInventoryScreen() {
        Intent inventoryIntent =
                new Intent(
                        MainActivity.this,
                        InventoryActivity.class
                );

        startActivity(inventoryIntent);
    }

    /**
     * Releases the database connection when this activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}