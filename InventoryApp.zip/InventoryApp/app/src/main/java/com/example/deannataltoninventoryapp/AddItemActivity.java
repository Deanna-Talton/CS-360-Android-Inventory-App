package com.example.deannataltoninventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Controls the Add Inventory Item screen.
 *
 * Validated inventory information is inserted into the persistent SQLite
 * database. The activity returns a success result so InventoryActivity can
 * refresh its grid after the record has been saved.
 */
public class AddItemActivity extends AppCompatActivity {

    public static final int RESULT_ITEM_SAVED = 100;

    private EditText editItemName;
    private EditText editDescription;
    private EditText editQuantity;
    private Spinner spinnerCategory;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editItemName = findViewById(R.id.editItemName);
        editDescription = findViewById(R.id.editDescription);
        editQuantity = findViewById(R.id.editQuantity);
        spinnerCategory = findViewById(R.id.spinnerCategory);

        Button buttonBack =
                findViewById(R.id.buttonBack);

        Button buttonSaveItem =
                findViewById(R.id.buttonSaveItem);

        Button buttonCancel =
                findViewById(R.id.buttonCancel);

        databaseHelper =
                new DatabaseHelper(getApplicationContext());

        /*
         * Back and Cancel intentionally discard the form without inserting a
         * database record.
         */
        buttonBack.setOnClickListener(
                view -> finish()
        );

        buttonCancel.setOnClickListener(
                view -> finish()
        );

        buttonSaveItem.setOnClickListener(
                view -> saveInventoryItem()
        );
    }

    /**
     * Validates user input before inserting a persistent inventory record.
     */
    private void saveInventoryItem() {
        String itemName =
                editItemName.getText().toString().trim();

        String description =
                editDescription.getText().toString().trim();

        String quantityText =
                editQuantity.getText().toString().trim();

        editItemName.setError(null);
        editQuantity.setError(null);

        if (itemName.isEmpty()) {
            editItemName.setError(
                    getString(R.string.item_name_required)
            );

            editItemName.requestFocus();
            return;
        }

        /*
         * The first spinner entry is an instruction rather than a valid
         * inventory category.
         */
        if (spinnerCategory.getSelectedItemPosition() == 0) {
            Toast.makeText(
                    this,
                    R.string.category_required,
                    Toast.LENGTH_SHORT
            ).show();

            spinnerCategory.performClick();
            return;
        }

        if (quantityText.isEmpty()) {
            editQuantity.setError(
                    getString(R.string.quantity_required)
            );

            editQuantity.requestFocus();
            return;
        }

        int quantity;

        try {
            quantity =
                    Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            editQuantity.setError(
                    getString(R.string.quantity_required)
            );

            editQuantity.requestFocus();
            return;
        }

        if (quantity < 0) {
            editQuantity.setError(
                    getString(R.string.quantity_cannot_be_negative)
            );

            editQuantity.requestFocus();
            return;
        }

        String selectedCategory =
                spinnerCategory.getSelectedItem().toString();

        long newItemId =
                databaseHelper.addInventoryItem(
                        itemName,
                        description,
                        selectedCategory,
                        quantity
                );

        if (newItemId == -1) {
            Toast.makeText(
                    this,
                    R.string.item_save_failed,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        /*
         * The result communicates only that the database changed.
         * InventoryActivity will reload the authoritative records from SQLite.
         */
        Intent resultIntent =
                new Intent();

        resultIntent.putExtra(
                DatabaseHelper.INVENTORY_COLUMN_ID,
                newItemId
        );

        setResult(
                RESULT_ITEM_SAVED,
                resultIntent
        );

        Toast.makeText(
                this,
                R.string.item_saved_message,
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }

    /**
     * Releases the database connection when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}