package com.example.deannataltoninventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Controls the database-backed warehouse inventory screen.
 *
 * Inventory records are read from SQLite and displayed in a two-column grid.
 * Users can search, add, edit, delete, increase, and decrease inventory items.
 */
public class InventoryActivity extends AppCompatActivity {

    private GridLayout inventoryGrid;
    private DatabaseHelper databaseHelper;

    /*
     * The displayed card references allow search results to be updated
     * without querying or modifying the database.
     */
    private final List<DisplayedInventoryCard> displayedCards =
            new ArrayList<>();

    private String currentSearchQuery = "";

    /**
     * Reloads the authoritative SQLite inventory after AddItemActivity saves
     * a new record.
     */
    private final ActivityResultLauncher<Intent> addItemLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode()
                                == AddItemActivity.RESULT_ITEM_SAVED) {

                            loadInventoryFromDatabase();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryGrid =
                findViewById(R.id.inventoryGrid);

        databaseHelper =
                new DatabaseHelper(getApplicationContext());

        configureToolbar();
        configureSearch();
        loadInventoryFromDatabase();
    }

    /**
     * Configures navigation, account, and add-item actions.
     */
    private void configureToolbar() {
        Button buttonAlerts =
                findViewById(R.id.buttonAlerts);

        Button buttonLogout =
                findViewById(R.id.buttonLogout);

        Button buttonAddItem =
                findViewById(R.id.buttonAddItem);

        buttonAlerts.setOnClickListener(view -> {
            Intent alertSettingsIntent =
                    new Intent(
                            InventoryActivity.this,
                            AlertSettingsActivity.class
                    );

            startActivity(alertSettingsIntent);
        });

        /*
         * Finishing the inventory activity returns the user to the login
         * screen without removing database information.
         */
        buttonLogout.setOnClickListener(
                view -> finish()
        );

        buttonAddItem.setOnClickListener(view -> {
            Intent addItemIntent =
                    new Intent(
                            InventoryActivity.this,
                            AddItemActivity.class
                    );

            addItemLauncher.launch(addItemIntent);
        });
    }

    /**
     * Filters displayed database records as the user types.
     */
    private void configureSearch() {
        EditText editSearchInventory =
                findViewById(R.id.editSearchInventory);

        editSearchInventory.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void beforeTextChanged(
                            CharSequence text,
                            int start,
                            int count,
                            int after
                    ) {
                        // No action is required before the text changes.
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence text,
                            int start,
                            int before,
                            int count
                    ) {
                        currentSearchQuery =
                                text.toString()
                                        .trim()
                                        .toLowerCase(Locale.ROOT);

                        filterInventoryCards();
                    }

                    @Override
                    public void afterTextChanged(Editable text) {
                        // Filtering is completed inside onTextChanged().
                    }
                }
        );
    }

    /**
     * Reads every inventory record from SQLite and rebuilds the visible grid.
     */
    private void loadInventoryFromDatabase() {
        inventoryGrid.removeAllViews();
        displayedCards.clear();

        try (Cursor cursor =
                     databaseHelper.getAllInventoryItems()) {

            int requiredRows =
                    Math.max(
                            1,
                            (cursor.getCount() + 1) / 2
                    );

            inventoryGrid.setRowCount(requiredRows);

            int idIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.INVENTORY_COLUMN_ID
                    );

            int nameIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.INVENTORY_COLUMN_NAME
                    );

            int descriptionIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.INVENTORY_COLUMN_DESCRIPTION
                    );

            int categoryIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.INVENTORY_COLUMN_CATEGORY
                    );

            int quantityIndex =
                    cursor.getColumnIndexOrThrow(
                            DatabaseHelper.INVENTORY_COLUMN_QUANTITY
                    );

            while (cursor.moveToNext()) {
                long itemId =
                        cursor.getLong(idIndex);

                String itemName =
                        cursor.getString(nameIndex);

                String description =
                        cursor.getString(descriptionIndex);

                String category =
                        cursor.getString(categoryIndex);

                int quantity =
                        cursor.getInt(quantityIndex);

                addInventoryCard(
                        itemId,
                        itemName,
                        description,
                        category,
                        quantity
                );
            }
        }

        filterInventoryCards();
    }

    /**
     * Creates one card for a database inventory record.
     */
    private void addInventoryCard(
            long itemId,
            String itemName,
            String description,
            String category,
            int startingQuantity
    ) {
        MaterialCardView itemCard =
                new MaterialCardView(this);

        int cardIndex =
                inventoryGrid.getChildCount();

        int row =
                cardIndex / 2;

        int column =
                cardIndex % 2;

        GridLayout.LayoutParams cardParameters =
                new GridLayout.LayoutParams(
                        GridLayout.spec(row, 1, 1f),
                        GridLayout.spec(column, 1, 1f)
                );

        cardParameters.width = 0;
        cardParameters.height =
                GridLayout.LayoutParams.WRAP_CONTENT;

        int cardMargin =
                dpToPixels(5);

        cardParameters.setMargins(
                cardMargin,
                cardMargin,
                cardMargin,
                cardMargin
        );

        itemCard.setLayoutParams(cardParameters);
        itemCard.setCardBackgroundColor(
                getColor(R.color.card_background)
        );
        itemCard.setRadius(dpToPixels(12));
        itemCard.setCardElevation(dpToPixels(3));
        itemCard.setStrokeWidth(dpToPixels(1));

        LinearLayout cardContent =
                new LinearLayout(this);

        cardContent.setLayoutParams(
                new MaterialCardView.LayoutParams(
                        MaterialCardView.LayoutParams.MATCH_PARENT,
                        MaterialCardView.LayoutParams.WRAP_CONTENT
                )
        );

        cardContent.setOrientation(
                LinearLayout.VERTICAL
        );

        cardContent.setGravity(
                Gravity.CENTER_HORIZONTAL
        );

        cardContent.setPadding(
                dpToPixels(12),
                dpToPixels(12),
                dpToPixels(12),
                dpToPixels(12)
        );

        TextView itemSymbol =
                createItemSymbol(category);

        TextView itemNameText =
                new TextView(this);

        itemNameText.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        itemNameText.setGravity(Gravity.CENTER);
        itemNameText.setMaxLines(2);
        itemNameText.setText(itemName);
        itemNameText.setTextColor(
                getColor(R.color.navy_primary)
        );
        itemNameText.setTextSize(15);
        itemNameText.setTypeface(
                itemNameText.getTypeface(),
                Typeface.BOLD
        );

        if (description != null
                && !description.trim().isEmpty()) {

            itemNameText.setTooltipText(
                    description.trim()
            );
        }

        TextView statusText =
                new TextView(this);

        LinearLayout.LayoutParams statusParameters =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        statusParameters.topMargin =
                dpToPixels(4);

        statusText.setLayoutParams(statusParameters);
        statusText.setGravity(Gravity.CENTER);
        statusText.setTextSize(12);
        statusText.setTypeface(
                statusText.getTypeface(),
                Typeface.BOLD
        );

        LinearLayout quantityRow =
                new LinearLayout(this);

        LinearLayout.LayoutParams quantityRowParameters =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        quantityRowParameters.topMargin =
                dpToPixels(8);

        quantityRow.setLayoutParams(
                quantityRowParameters
        );

        quantityRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        quantityRow.setGravity(Gravity.CENTER);

        Button decreaseButton =
                createQuantityButton(
                        getString(R.string.decrease_quantity),
                        R.color.border_light,
                        R.color.navy_primary
                );

        TextView quantityText =
                new TextView(this);

        quantityText.setLayoutParams(
                new LinearLayout.LayoutParams(
                        dpToPixels(46),
                        dpToPixels(48)
                )
        );

        quantityText.setGravity(Gravity.CENTER);
        quantityText.setText(
                String.valueOf(startingQuantity)
        );
        quantityText.setTextSize(18);
        quantityText.setTypeface(
                quantityText.getTypeface(),
                Typeface.BOLD
        );

        Button increaseButton =
                createQuantityButton(
                        getString(R.string.increase_quantity),
                        R.color.teal_primary,
                        R.color.white
                );

        decreaseButton.setContentDescription(
                getString(
                        R.string.decrease_quantity_description
                )
        );

        increaseButton.setContentDescription(
                getString(
                        R.string.increase_quantity_description
                )
        );

        quantityRow.addView(decreaseButton);
        quantityRow.addView(quantityText);
        quantityRow.addView(increaseButton);

        LinearLayout actionRow =
                new LinearLayout(this);

        LinearLayout.LayoutParams actionRowParameters =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        actionRowParameters.topMargin =
                dpToPixels(8);

        actionRow.setLayoutParams(
                actionRowParameters
        );

        actionRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        Button editButton =
                createActionButton(
                        getString(R.string.edit_item),
                        R.color.teal_primary
                );

        Button deleteButton =
                createActionButton(
                        getString(R.string.remove_item),
                        R.color.status_out_of_stock
                );

        LinearLayout.LayoutParams deleteParameters =
                (LinearLayout.LayoutParams)
                        deleteButton.getLayoutParams();

        deleteParameters.setMarginStart(
                dpToPixels(4)
        );

        deleteButton.setLayoutParams(
                deleteParameters
        );

        actionRow.addView(editButton);
        actionRow.addView(deleteButton);

        cardContent.addView(itemSymbol);
        cardContent.addView(itemNameText);
        cardContent.addView(statusText);
        cardContent.addView(quantityRow);
        cardContent.addView(actionRow);

        itemCard.addView(cardContent);
        inventoryGrid.addView(itemCard);

        DisplayedInventoryCard displayedCard =
                new DisplayedInventoryCard(
                        itemName,
                        itemCard
                );

        displayedCards.add(displayedCard);

        updateCardStatus(
                startingQuantity,
                quantityText,
                statusText,
                decreaseButton,
                itemCard
        );

        decreaseButton.setOnClickListener(view -> {
            int currentQuantity =
                    Integer.parseInt(
                            quantityText
                                    .getText()
                                    .toString()
                    );

            if (currentQuantity <= 0) {
                return;
            }

            int updatedQuantity =
                    currentQuantity - 1;

            boolean updated =
                    databaseHelper.updateInventoryQuantity(
                            itemId,
                            updatedQuantity
                    );

            if (!updated) {
                showDatabaseUpdateFailure();
                return;
            }

            updateCardStatus(
                    updatedQuantity,
                    quantityText,
                    statusText,
                    decreaseButton,
                    itemCard
            );

            /*
             * The notification trigger occurs only during the transition from
             * a positive quantity to zero. Opening an existing zero-value item
             * does not repeatedly notify the user.
             */
            if (updatedQuantity == 0) {
                handleZeroQuantity(itemName);
            }
        });

        increaseButton.setOnClickListener(view -> {
            int currentQuantity =
                    Integer.parseInt(
                            quantityText
                                    .getText()
                                    .toString()
                    );

            int updatedQuantity =
                    currentQuantity + 1;

            boolean updated =
                    databaseHelper.updateInventoryQuantity(
                            itemId,
                            updatedQuantity
                    );

            if (!updated) {
                showDatabaseUpdateFailure();
                return;
            }

            updateCardStatus(
                    updatedQuantity,
                    quantityText,
                    statusText,
                    decreaseButton,
                    itemCard
            );
        });

        editButton.setOnClickListener(
                view -> showEditItemDialog(
                        itemId,
                        itemName,
                        description,
                        category,
                        Integer.parseInt(
                                quantityText
                                        .getText()
                                        .toString()
                        )
                )
        );

        deleteButton.setOnClickListener(
                view -> showDeleteConfirmation(
                        itemId,
                        itemName
                )
        );
    }

    /**
     * Uses a compact symbol to visually distinguish item categories.
     */
    private TextView createItemSymbol(String category) {
        TextView itemSymbol =
                new TextView(this);

        itemSymbol.setLayoutParams(
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        dpToPixels(48)
                )
        );

        itemSymbol.setGravity(Gravity.CENTER);
        itemSymbol.setText(
                selectCategorySymbol(category)
        );
        itemSymbol.setTextColor(
                getColor(R.color.status_low_stock)
        );
        itemSymbol.setTextSize(38);

        /*
         * The decorative symbol is hidden from accessibility services because
         * the adjacent item name communicates the meaningful information.
         */
        itemSymbol.setImportantForAccessibility(
                View.IMPORTANT_FOR_ACCESSIBILITY_NO
        );

        return itemSymbol;
    }

    /**
     * Selects a simple category symbol without requiring external image files.
     */
    private String selectCategorySymbol(String category) {
        String normalizedCategory =
                category == null
                        ? ""
                        : category.toLowerCase(Locale.ROOT);

        if (normalizedCategory.contains("safety")) {
            return "◆";
        }

        if (normalizedCategory.contains("office")) {
            return "▤";
        }

        if (normalizedCategory.contains("pack")) {
            return "●";
        }

        if (normalizedCategory.contains("ship")) {
            return "■";
        }

        if (normalizedCategory.contains("tool")) {
            return "⬟";
        }

        return "■";
    }

    /**
     * Updates one card after its quantity changes.
     */
    private void updateCardStatus(
            int quantity,
            TextView quantityText,
            TextView statusText,
            Button decreaseButton,
            MaterialCardView itemCard
    ) {
        quantityText.setText(
                String.valueOf(quantity)
        );

        decreaseButton.setEnabled(
                quantity > 0
        );

        if (quantity == 0) {
            quantityText.setTextColor(
                    getColor(R.color.status_out_of_stock)
            );

            statusText.setText(
                    R.string.status_out_of_stock_text
            );

            statusText.setTextColor(
                    getColor(R.color.status_out_of_stock)
            );

            itemCard.setStrokeColor(
                    getColor(R.color.status_out_of_stock)
            );

            return;
        }

        if (quantity <= 3) {
            quantityText.setTextColor(
                    getColor(R.color.status_low_stock)
            );

            statusText.setText(
                    R.string.status_low_stock_text
            );

            statusText.setTextColor(
                    getColor(R.color.status_low_stock)
            );

            itemCard.setStrokeColor(
                    getColor(R.color.status_low_stock)
            );

            return;
        }

        quantityText.setTextColor(
                getColor(R.color.navy_primary)
        );

        statusText.setText(
                R.string.status_available_text
        );

        statusText.setTextColor(
                getColor(R.color.status_available)
        );

        itemCard.setStrokeColor(
                getColor(R.color.border_light)
        );
    }

    /**
     * Handles the application's zero-quantity notification trigger.
     *
     * Every user receives an in-app warning. An SMS is also sent when the user
     * has granted SEND_SMS permission and saved a destination phone number.
     * Missing permission never interrupts the application's inventory features.
     */
    private void handleZeroQuantity(String itemName) {
        /*
         * The in-app notification remains available regardless of whether the
         * user enabled the optional SMS feature.
         */
        Toast.makeText(
                this,
                getString(
                        R.string.zero_inventory_item_message,
                        itemName
                ),
                Toast.LENGTH_LONG
        ).show();

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        /*
         * Respect the user's permission decision. If SMS access was denied,
         * inventory processing continues without attempting to send a message.
         */
        if (!permissionGranted) {
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences(
                        AlertSettingsActivity.ALERT_PREFERENCES,
                        MODE_PRIVATE
                );

        String phoneNumber =
                preferences.getString(
                        AlertSettingsActivity.KEY_ALERT_PHONE_NUMBER,
                        ""
                );

        /*
         * A message cannot be delivered without a saved destination number.
         * Returning here leaves every other inventory feature operational.
         */
        if (phoneNumber == null
                || phoneNumber.trim().isEmpty()) {

            return;
        }

        String alertMessage =
                getString(
                        R.string.sms_alert_message,
                        itemName
                );

        try {
            /*
             * SmsManager uses Android's available SMS service to deliver the
             * inventory alert to the number configured by the user.
             */
            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            if (smsManager == null) {
                Toast.makeText(
                        this,
                        R.string.sms_alert_failed,
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            smsManager.sendTextMessage(
                    phoneNumber.trim(),
                    null,
                    alertMessage,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    R.string.sms_alert_sent,
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception exception) {
            /*
             * SMS failures are contained so unsupported service, emulator, or
             * carrier conditions cannot crash the inventory application.
             */
            Toast.makeText(
                    this,
                    R.string.sms_alert_failed,
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    /**
     * Displays a form containing the item's current database values.
     */
    private void showEditItemDialog(
            long itemId,
            String currentName,
            String currentDescription,
            String currentCategory,
            int currentQuantity
    ) {
        LinearLayout formLayout =
                new LinearLayout(this);

        formLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        int horizontalPadding =
                dpToPixels(24);

        formLayout.setPadding(
                horizontalPadding,
                dpToPixels(8),
                horizontalPadding,
                0
        );

        EditText nameInput =
                new EditText(this);

        nameInput.setHint(
                R.string.item_name_hint
        );

        nameInput.setText(currentName);
        nameInput.setSingleLine(true);

        EditText descriptionInput =
                new EditText(this);

        descriptionInput.setHint(
                R.string.description_hint
        );

        descriptionInput.setText(
                currentDescription == null
                        ? ""
                        : currentDescription
        );

        EditText categoryInput =
                new EditText(this);

        categoryInput.setHint(
                R.string.category_label
        );

        categoryInput.setText(
                currentCategory == null
                        ? ""
                        : currentCategory
        );

        categoryInput.setSingleLine(true);

        EditText quantityInput =
                new EditText(this);

        quantityInput.setHint(
                R.string.quantity_hint
        );

        quantityInput.setText(
                String.valueOf(currentQuantity)
        );

        quantityInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );

        formLayout.addView(nameInput);
        formLayout.addView(descriptionInput);
        formLayout.addView(categoryInput);
        formLayout.addView(quantityInput);

        new AlertDialog.Builder(this)
                .setTitle(R.string.edit_inventory_title)
                .setView(formLayout)
                .setNegativeButton(
                        R.string.cancel_button,
                        null
                )
                .setPositiveButton(
                        R.string.update_item_button,
                        (dialog, which) -> updateInventoryItem(
                                itemId,
                                nameInput,
                                descriptionInput,
                                categoryInput,
                                quantityInput
                        )
                )
                .show();
    }

    /**
     * Validates edited values and updates the matching SQLite record.
     */
    private void updateInventoryItem(
            long itemId,
            EditText nameInput,
            EditText descriptionInput,
            EditText categoryInput,
            EditText quantityInput
    ) {
        String updatedName =
                nameInput.getText().toString().trim();

        String updatedDescription =
                descriptionInput.getText().toString().trim();

        String updatedCategory =
                categoryInput.getText().toString().trim();

        String updatedQuantityText =
                quantityInput.getText().toString().trim();

        if (updatedName.isEmpty()
                || updatedQuantityText.isEmpty()) {

            Toast.makeText(
                    this,
                    R.string.edit_values_required,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int updatedQuantity;

        try {
            updatedQuantity =
                    Integer.parseInt(
                            updatedQuantityText
                    );
        } catch (NumberFormatException exception) {
            Toast.makeText(
                    this,
                    R.string.quantity_required,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (updatedCategory.isEmpty()) {
            updatedCategory = "Other";
        }

        boolean updated =
                databaseHelper.updateInventoryItem(
                        itemId,
                        updatedName,
                        updatedDescription,
                        updatedCategory,
                        updatedQuantity
                );

        if (!updated) {
            showDatabaseUpdateFailure();
            return;
        }

        Toast.makeText(
                this,
                R.string.item_updated_message,
                Toast.LENGTH_SHORT
        ).show();

        loadInventoryFromDatabase();
    }

    /**
     * Requires confirmation before permanently deleting a database record.
     */
    private void showDeleteConfirmation(
            long itemId,
            String itemName
    ) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_item_title)
                .setMessage(
                        getString(
                                R.string.delete_item_confirmation,
                                itemName
                        )
                )
                .setNegativeButton(
                        R.string.cancel_button,
                        null
                )
                .setPositiveButton(
                        R.string.remove_item,
                        (dialog, which) -> deleteInventoryItem(
                                itemId
                        )
                )
                .show();
    }

    /**
     * Deletes a record from SQLite and refreshes the grid.
     */
    private void deleteInventoryItem(long itemId) {
        boolean deleted =
                databaseHelper.deleteInventoryItem(
                        itemId
                );

        if (!deleted) {
            Toast.makeText(
                    this,
                    R.string.item_delete_failed,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Toast.makeText(
                this,
                R.string.item_removed_message,
                Toast.LENGTH_SHORT
        ).show();

        loadInventoryFromDatabase();
    }

    /**
     * Applies the active search query to all displayed cards.
     */
    private void filterInventoryCards() {
        for (DisplayedInventoryCard displayedCard
                : displayedCards) {

            boolean matchesSearch =
                    currentSearchQuery.isEmpty()
                            || displayedCard.itemName
                            .toLowerCase(Locale.ROOT)
                            .contains(currentSearchQuery);

            displayedCard.card.setVisibility(
                    matchesSearch
                            ? View.VISIBLE
                            : View.GONE
            );
        }
    }

    /**
     * Creates a circular quantity control matching the original UI.
     */
    private Button createQuantityButton(
            String buttonText,
            int backgroundColorResource,
            int textColorResource
    ) {
        Button button =
                new Button(this);

        button.setLayoutParams(
                new LinearLayout.LayoutParams(
                        dpToPixels(48),
                        dpToPixels(48)
                )
        );

        button.setMinWidth(dpToPixels(48));
        button.setMinHeight(dpToPixels(48));
        button.setPadding(0, 0, 0, 0);
        button.setText(buttonText);
        button.setTextSize(20);
        button.setTextColor(
                getColor(textColorResource)
        );

        GradientDrawable roundedBackground =
                new GradientDrawable();

        /*
         * OVAL guarantees a true circle when the button has equal width and
         * height, avoiding clipped or stretched rounded corners.
         */
        roundedBackground.setShape(
                GradientDrawable.OVAL
        );

        roundedBackground.setColor(
                getColor(backgroundColorResource)
        );

        /*
         * The inset keeps the circular background away from the exact edges
         * of the view so Android does not visually clip its outline.
         */
        InsetDrawable insetBackground =
                new InsetDrawable(
                        roundedBackground,
                        dpToPixels(2)
                );

        button.setBackground(
                insetBackground
        );

        button.setElevation(0);

        return button;
    }

    /**
     * Creates a compact Edit or Delete action for an inventory card.
     */
    private Button createActionButton(
            String buttonText,
            int textColorResource
    ) {
        Button button =
                new Button(this);

        button.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        dpToPixels(48),
                        1f
                )
        );

        button.setMinWidth(0);
        button.setMinHeight(dpToPixels(48));
        button.setPadding(0, 0, 0, 0);
        button.setText(buttonText);
        button.setTextSize(11);
        button.setTextColor(
                getColor(textColorResource)
        );
        button.setAllCaps(false);
        button.setSingleLine(true);
        button.setBackgroundColor(
                Color.TRANSPARENT
        );
        button.setStateListAnimator(null);
        button.setElevation(0);

        return button;
    }

    /**
     * Displays a consistent failure message when SQLite cannot update a row.
     */
    private void showDatabaseUpdateFailure() {
        Toast.makeText(
                this,
                R.string.item_update_failed,
                Toast.LENGTH_SHORT
        ).show();
    }

    /**
     * Converts density-independent pixels to physical screen pixels.
     */
    private int dpToPixels(int dpValue) {
        float density =
                getResources()
                        .getDisplayMetrics()
                        .density;

        return Math.round(
                dpValue * density
        );
    }

    /**
     * Releases the database connection when the activity is destroyed.
     */
    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }

    /**
     * Associates a displayed card with its searchable inventory name.
     */
    private static class DisplayedInventoryCard {

        private final String itemName;
        private final MaterialCardView card;

        private DisplayedInventoryCard(
                String itemName,
                MaterialCardView card
        ) {
            this.itemName = itemName;
            this.card = card;
        }
    }
}