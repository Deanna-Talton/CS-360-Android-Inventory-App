package com.example.deannataltoninventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Manages the optional SMS permission and destination phone number used for
 * zero-inventory alerts.
 *
 * The user receives an explanation before Android displays the permission
 * request. Denying permission does not prevent access to inventory features.
 */
public class AlertSettingsActivity extends AppCompatActivity {

    /*
     * These public constants allow InventoryActivity to retrieve the saved
     * phone number without duplicating preference names.
     */
    public static final String ALERT_PREFERENCES =
            "alert_preferences";

    public static final String KEY_ALERT_PHONE_NUMBER =
            "alert_phone_number";

    private EditText editAlertPhoneNumber;
    private TextView textPermissionStatus;

    /*
     * ActivityResultLauncher receives the result of Android's asynchronous
     * runtime permission request.
     */
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_settings);

        /*
         * Connect the Java fields and controls to their corresponding
         * components in activity_alert_settings.xml.
         */
        editAlertPhoneNumber =
                findViewById(R.id.editAlertPhoneNumber);

        textPermissionStatus =
                findViewById(R.id.textPermissionStatus);

        Button buttonAlertBack =
                findViewById(R.id.buttonAlertBack);

        Button buttonEnableAlerts =
                findViewById(R.id.buttonEnableAlerts);

        Button buttonNotNow =
                findViewById(R.id.buttonNotNow);

        /*
         * Display a previously saved destination number when the user
         * returns to the alert settings screen.
         */
        loadSavedPhoneNumber();

        /*
         * Register the permission callback before attempting to launch it.
         * Both approval and denial are handled without interrupting access
         * to the rest of the application.
         */
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                permissionGranted -> {
                    if (permissionGranted) {
                        displayPermissionGranted();
                    } else {
                        displayPermissionDenied();
                    }
                }
        );

        /*
         * Both navigation buttons return to the inventory screen. Choosing
         * Not Now does not display Android's permission request.
         */
        buttonAlertBack.setOnClickListener(
                view -> finish()
        );

        buttonNotNow.setOnClickListener(
                view -> finish()
        );

        /*
         * The phone number is validated and stored before SMS permission is
         * requested.
         */
        buttonEnableAlerts.setOnClickListener(
                view -> saveNumberAndRequestPermission()
        );

        updateCurrentPermissionStatus();
    }

    /**
     * Loads the locally stored destination phone number into the input field.
     */
    private void loadSavedPhoneNumber() {
        SharedPreferences preferences =
                getSharedPreferences(
                        ALERT_PREFERENCES,
                        MODE_PRIVATE
                );

        String savedPhoneNumber =
                preferences.getString(
                        KEY_ALERT_PHONE_NUMBER,
                        ""
                );

        editAlertPhoneNumber.setText(savedPhoneNumber);
    }

    /**
     * Validates and stores the destination number before requesting access
     * to Android's SMS functionality.
     */
    private void saveNumberAndRequestPermission() {
        String phoneNumber =
                editAlertPhoneNumber
                        .getText()
                        .toString()
                        .trim();

        /*
         * A destination number is required because SEND_SMS permission alone
         * does not tell the application where to deliver an alert.
         */
        if (phoneNumber.isEmpty()) {
            editAlertPhoneNumber.setError(
                    getString(R.string.alert_phone_required)
            );

            editAlertPhoneNumber.requestFocus();
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences(
                        ALERT_PREFERENCES,
                        MODE_PRIVATE
                );

        preferences.edit()
                .putString(
                        KEY_ALERT_PHONE_NUMBER,
                        phoneNumber
                )
                .apply();

        requestSmsPermission();
    }

    /**
     * Checks the current permission so returning users see an accurate status.
     *
     * The permission status is checked directly because Android emulators do
     * not always report the optional telephony feature consistently.
     */
    private void updateCurrentPermissionStatus() {
        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted) {
            textPermissionStatus.setText(
                    R.string.permission_granted
            );

            textPermissionStatus.setTextColor(
                    getColor(R.color.status_available)
            );
        } else {
            textPermissionStatus.setText(
                    R.string.permission_not_granted
            );

            textPermissionStatus.setTextColor(
                    getColor(R.color.status_low_stock)
            );
        }
    }

    /**
     * Requests SEND_SMS when permission has not already been granted.
     *
     * SMS service failures are handled later when the application attempts
     * delivery, preventing unsupported devices from crashing the app.
     */
    private void requestSmsPermission() {
        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        /*
         * Android does not need to display the permission dialog again when
         * access has already been approved. The newly entered phone number
         * has still been saved.
         */
        if (permissionGranted) {
            Toast.makeText(
                    this,
                    R.string.alert_phone_saved,
                    Toast.LENGTH_SHORT
            ).show();

            displayPermissionGranted();
            return;
        }

        smsPermissionLauncher.launch(
                Manifest.permission.SEND_SMS
        );
    }

    /**
     * Updates the screen after the user approves SMS access.
     */
    private void displayPermissionGranted() {
        textPermissionStatus.setText(
                R.string.permission_granted
        );

        textPermissionStatus.setTextColor(
                getColor(R.color.status_available)
        );

        Toast.makeText(
                this,
                R.string.alerts_enabled_message,
                Toast.LENGTH_SHORT
        ).show();
    }

    /**
     * Updates the screen after the user denies SMS access.
     *
     * No screen is closed and no inventory feature is disabled. The user can
     * continue using the application without SMS notifications.
     */
    private void displayPermissionDenied() {
        textPermissionStatus.setText(
                R.string.permission_denied
        );

        textPermissionStatus.setTextColor(
                getColor(R.color.status_out_of_stock)
        );

        Toast.makeText(
                this,
                R.string.alerts_denied_message,
                Toast.LENGTH_LONG
        ).show();
    }
}